import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-action-nav',
  templateUrl: './action-nav.component.html',
  styleUrls: ['./action-nav.component.css']
})
export class ActionNavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
