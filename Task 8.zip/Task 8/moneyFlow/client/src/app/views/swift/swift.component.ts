import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-swift',
  templateUrl: './swift.component.html',
  styleUrls: ['./swift.component.css']
})
export class SwiftComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
