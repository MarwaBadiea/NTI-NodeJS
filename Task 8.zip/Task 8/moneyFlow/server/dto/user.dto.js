const UserDto = ({_id, name, email}) => ({ id: _id, name, email })

// const UserDTO = ({_id, name, email}) => {
//     return {
//         id: _id, 
//         name,
//         email
//     }
// }

module.exports = {UserDto}