const express = require('express');

const router = express.Router();


const user = {
    id: 1,
    name: 'marwa'
};

const articles = [];
let lastId = 0;

router.get('/', (req, res) => {
    res.status(200).json({
        articles
    });
});

//make dynamic id
router.get('/:id', (req, res) => {
    const {id} = req.params;
    
    const article = articles.find((art) => art.id == id);

    if (!article) return res.status(404).json({msg: 'article not found'});

    res.json({
        article
    });
});

router.post('/', (req, res) => {
    const{ title, content} = req.body;
    lastId++;

    const article = {
        id: lastId,
        title,
        content,
        createdAt: new Date(),
        publisher: user
    }
    articles.push(article);

    res.status(200).json({
        articles
    });
});

// update article content
router.put('/:id', (req, res) => {
    const {id} = req.params;
    const {title, content} = req.body;
    
    const article = articles.find((art) => art.id == id);

    if (!article) return res.status(404).json({msg: 'article not found'});

    article.title = title ? title : article.title;
    article.content = content ? content : article.content;

    res.json({
        article
    });
});


// delete article content
router.delete('/:id', (req, res) => {
    const {id} = req.params;

    const articleIndex = getArticleIndex(req.params.id);

    const article = articles.find((art) => art.id == id);

    if (!article) return res.status(404).json({msg: 'article not found'});

    articles.splice(articleIndex, 1);

    res.json({
        articles
    });
});


module.exports = router;
