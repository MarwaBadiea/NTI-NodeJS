import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SignupComponent } from './pages/signup/signup.component';
import { FormsModule } from '@angular/forms';
import { SigninComponent } from './pages/signin/signin.component';
import { HomeComponent } from './pages/home/home.component';
import { HomeNavComponent } from './components/nav-bar/home-nav/home-nav.component';
import { NotFoundComponent } from './pages/not-found/not-found.component';
import { TodoDetailsComponent } from './pages/todo-details/todo-details.component';
import { TodosComponent } from './pages/todos/todos.component';
import { AddEditTodoComponent } from './pages/add-edit-todo/add-edit-todo.component';
import { TodoListComponent } from './components/todo-list/todo-list.component';
import { TodoListItemComponent } from './components/todo-list-item/todo-list-item.component';
import { ActionsNavComponent } from './components/nav-bar/actions-nav/actions-nav.component';


@NgModule({
  declarations: [
    AppComponent,
    SignupComponent,
    SigninComponent,
    HomeComponent,
    HomeNavComponent,
    NotFoundComponent,
    TodoDetailsComponent,
    TodosComponent,
    AddEditTodoComponent,
    TodoListComponent,
    TodoListItemComponent,
    ActionsNavComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
