import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TodosService } from 'src/app/services/todos.service';

@Component({
  selector: 'app-add-edit-todo',
  templateUrl: './add-edit-todo.component.html',
  styleUrls: ['./add-edit-todo.component.css']
})
export class AddEditTodoComponent implements OnInit {

  title: string = '';
  content: string = '';
  todoId: string = '';
  editMode: boolean = false;

  constructor(private todosService: TodosService, private route: ActivatedRoute) { }

  ngOnInit(): void {

    const id = this.route.snapshot.paramMap.get('id')!;
    if (id != 'new') {
      const todo = this.todosService.getTodosById(id);
      this.title = todo?.title!;
      this.content = todo?.content!;
      this.todoId = id;
      this.editMode = true;
    }

  }

  submit() {
    if (this.editMode) {
      this.todosService.updateTodo(this.todoId, {
        title: this.title,
        content: this.content
      })
    } else {
      this.todosService.createTodo(this.title, this.content)
    }
  }

  }


