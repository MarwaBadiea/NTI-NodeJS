import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuardGuard } from './guards/auth-guard.guard';
import { UnAuthGuardGuard } from './guards/un-auth-guard.guard';
import { AddEditTodoComponent } from './pages/add-edit-todo/add-edit-todo.component';
import { HomeComponent } from './pages/home/home.component';
import { NotFoundComponent } from './pages/not-found/not-found.component';
import { SigninComponent } from './pages/signin/signin.component';
import { SignupComponent } from './pages/signup/signup.component';
import { TodoDetailsComponent } from './pages/todo-details/todo-details.component';
import { TodosComponent } from './pages/todos/todos.component';

const routes: Routes = [
  {
    path: "",
    component: HomeComponent,
    canActivate: [UnAuthGuardGuard]
  },
  {
    path: "signup",
    component: SignupComponent,
    canActivate: [UnAuthGuardGuard]
  },
  {
    path: "signin",
    component: SigninComponent,
    canActivate: [UnAuthGuardGuard]
  },
  {
    path: "add-edit-todo/:id",
    component: AddEditTodoComponent,
    canActivate: [AuthGuardGuard]
  },
  {
    path: "todos",
    component: TodosComponent,
    canActivate: [AuthGuardGuard]
  },
  {
    path: "todos/:id",
    component: TodoDetailsComponent,
    canActivate: [AuthGuardGuard]
  },
  {
    path: "**",
    component: NotFoundComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
