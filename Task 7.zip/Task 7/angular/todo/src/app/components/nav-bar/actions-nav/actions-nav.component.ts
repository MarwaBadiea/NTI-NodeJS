import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-actions-nav',
  templateUrl: './actions-nav.component.html',
  styleUrls: ['./actions-nav.component.css']
})
export class ActionsNavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
