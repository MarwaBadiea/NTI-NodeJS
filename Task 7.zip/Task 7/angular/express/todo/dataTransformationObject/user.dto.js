// this file for what i want to return from user information

function UserDTO({_id, name, email, createdAt}) {
    return {
        id: _id,
        name,
        email,
        createdAt
    };
};

module.exports = {UserDTO};