//var createError = require('http-error');   // To handle error
var express = require('express');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
const {connectToDB} = require('./config/db');
const cors = require('cors');

const todoRouter = require('./routes/todo');

const authRouter = require('./routes/auth');

var app = express();

connectToDB();

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false}));
app.use(cookieParser());
app.use(cors());

//when the url contains /todo it will use the file called todoRouter
app.use('/todo', todoRouter);

//when the url contains /auth it will use the file called authRouter
app.use('/auth', authRouter);


// catch 404 for error
app.use(function(req, res, next) {
    next(createError(404));
});

// to handle error
app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.json({err});
});

module.exports = app;