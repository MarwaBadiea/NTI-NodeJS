const express = require('express');

const router = express.Router();

const {Todo} = require('../models/todo.model');

const {validateToken} = require('../middleware/validate-token');


const user = { 
    name: 'marwa',
    id: 1
};

const todos = [];
let lastId = 0;

router.get('/', async (req, res) => {

    const todos = await Todo.find();

    res.status(200).json({
        todos
    });
});

//make dynamic id
router.get('/:id', async (req, res) => {
    const {id} = req.params;

    try {
    const todo = await Todo.findById(id);

    if (!todo) return res.status(404).json({msg: 'todo not found'});

    res.json({
        todo
    });

    } catch(err) {
        console.log(err);
        res.status(400).json({msg: 'invalid id'});
    }
});

router.post('/', validateToken, async (req, res) => {
    const{ title, content} = req.body;

    const todo = new Todo({
        title,
        content,
        publisher: req.user
    });
        
    await todo.save();

    res.status(200).json({
        todo
    });
});

// update article content
router.put('/:id', validateToken, async (req, res) => {
    const {id} = req.params;
    const {title, content} = req.body;

    const user = req.user;
    
    const todo = await Todo.findById(id);

    if(todo.publisher.id != user.id) return res.status(403).json({msg: 'you are not allowed for this action'})

    todo.title = title ? title : todo.title;
    todo.content = content ? content : todo.content;

    await todo.save();

    res.json({
        todo
    });
});


// delete article content
router.delete('/:id', validateToken, async (req, res) => {
    const {id} = req.params;

    const user = req.user;

    const todo = await Todo.findOneAndRemove({
        _id: id,
        'publisher.id': user.id,
    });

    if (!todo) return res.status(404).json({msg: 'todo not found'});

    res.status(200).json({
        msg: 'todo deleted successfully'
    });
});



module.exports = router;
