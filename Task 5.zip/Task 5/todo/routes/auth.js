const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const {User} = require('../models/user');

const {UserDTO} = require('../dataTransformationObject/user.dto');



router.post('/signup', async (req, res) => {

    const {name, email, password} = req.body;

    const existUser = await User.findOne({
        email
    });

    if(existUser) return res.status(400).json({
        msg: 'user already exists with given email'
    });

    const user = new User({
        name, email, type: 'publisher'
    });

    const hashPassword = bcrypt.hashSync(password, 10); // will make 10 rounds with hash
    user.password = hashPassword;

    await user.save();

    res.status(201).json({ //201 for create
        user
    });
});


router.post('/signin', async (req, res) => {
    const {email, password} = req.body;

    const user = await User.findOne({email});

    if(!user) return res.status(404).json({msg: 'user not found with given email'});

    const correctPassword = bcrypt.compareSync(password, user.password);

    if(!correctPassword) return res.status(401).json({msg: 'incorrect password'}); //401 for unauthorized

    const userData = UserDTO(user);

    const token = jwt.sign(userData, '12345') //this is to verify the user -- 12345 => any random password

    res.status(200).json({
        user: userData,
        token
    });
});


module.exports = router;