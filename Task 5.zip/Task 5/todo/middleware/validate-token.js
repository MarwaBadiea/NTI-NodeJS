const jwt = require('jsonwebtoken');

const validateToken = (req, res, next) => {
    const authorization = req.headers.authorization; //to send the token to the header

    if(!authorization) return res.status(401).json({msg: 'invalid token'});

    const token = authorization.split(' ')[1];

    try {
        const user = jwt.verify(token, '12345');
        req.user = user;
        next();
    } catch (err) {
        console.log(err);
        res.status(401).json({msg: 'invalid token'})
    }
};

module.exports = {validateToken};